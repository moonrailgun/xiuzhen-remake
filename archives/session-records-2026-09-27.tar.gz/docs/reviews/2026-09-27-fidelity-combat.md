# 战斗资料保真修复记录

日期：2026-09-27。对应审计 F07、F09、F10、F11，以及 F21 的天雷万磁剑效果；接入 F19 的调教侠客时长、F20 的护法援军与 F22 的免战。本记录描述本次工作区实现与验证，不表示所有战斗公式均已取得原版代码。

## 证据与裁决

| 项目 | 可核对的证据 | 本次实现与重建边界 |
| --- | --- | --- |
| 三主动剑术 | [9260 攻略](../../reference/text/guides/9260-p1.txt)第 42、44、46 行：碎玉损剑换攻击翻倍；小周天敏捷翻倍、攻击降至 25%；吸星吸收翻倍、耐久降至 25%。[研究记录](../research/02-guides-and-rules.md)§3.6 和冲突表 E6 记录原 DOM 与封测攻略冲突。 | 出击、支援、主动祭剑均选择已学剑术，结算使用出鞘时快照。吸星采用 25%，不采用较早 [4285](../../reference/text/guides/4285-p1.txt)第 31 行的耐久降至 1。碎玉按“有去无回”不生成自身返航、不运回战利品；同时按“损坏飞剑”保留可修实体，此组合是重建。 |
| 普通断剑与降级 | [17173 对 9 月 25 日维护的记录](../../reference/text/third-party/17173-live/20081031174401384.txt)第 101–105 行：新增修理，攻击中伤害大于自身一半降级。 | 玩家和 NPC 共用战损函数，普通断剑保留为“损坏”。严格大于本场有效耐久一半时降炼数；每场降 1、最低 +0，以及双方统一应用此规则为重建。 |
| 护身争取时间 | [护身揭密](../../reference/text/guides/4295-p1.txt)第 28–32 行：未祭起的剑没有出击被动，护身抵挡时间由敏捷决定；第 46–47 行：上品指玄 +0 敏捷 180，+5 撑 1.6 小时。 | 来袭拆成飞行、护身、飞剑交战，护身敏捷实际换成游戏秒：上品 +5 为 5760 秒。此期间可祭剑与求援；祭剑后获得出击被动及所选主动剑术。多护身时长相加、护身结束后参加共同结算是未见完整原式后的重建。 |
| 吸收与掠夺 | [4285](../../reference/text/guides/4285-p1.txt)第 30、48 行把吸收解释为成功击中后带回的真气，并列出单次 3000、6000 等数值。 | 先扣固本保护，再由己方幸存返航剑的吸收合计限制五气总量。五气按可掠夺库存比例分配、余数按固定五行次序补齐属于重建。玩家战利品返航到账，NPC 来袭所得也在真实返航后入账。 |
| 天雷万磁剑 | [法宝原文](../../reference/text/forum162/article-94153-p1.txt)第 231–237 行：销毁已损坏飞剑，只能青山出鞘，无属性，御剑术 20。 | 玩家、来袭 NPC、援军的出鞘均检查青山；胜方有天雷时销毁对方战前已有断剑，本次刚打断的剑仍保留可修。以胜负为触发条件、以战前状态划分“已损坏”是重建，NPC 守胜及双方护法亦对称处理。 |
| NPC 世界状态 | 原版联网玩家不能等同于本地 NPC；没有完整 NPC 原表可套用。 | 沿用种子生成的 NPC 成长与挑人模型，初始装备按现有成长面板重建。一旦出剑或受击，将真实装备、忙碌状态、战损、炼数、坐标写入稀疏补丁；不再临时生成对手面板。被抢扣库存而不倒减累计道行。初始配装、成长、击退规则均是单机重建。 |

本次不修改原始资料。具体战斗伤害分摊、NPC 自主行为和训练系列的缺失数值仍沿用项目重建规则，不能据上述修复声称完全复原原版战斗。

## 实际调用链与接口

- `battle.ts`：`LaunchOptions.swordArt?: '碎玉剑法' | '小周天剑法' | '吸星剑法'`。`launch`、`reinforce` 与 `defendRaid` 共用学习、空闲装备、御剑术、数量上限及天雷地形校验。`launchedStats` 保存本次属性，旧快照缺少 `absorb` 时只补缺项，不重算其已有面板。任务目标可带 `trainingSeconds` / `questId`；训练期间飞剑一直占用，仍保留前后飞行时间。
- `raid.ts`：生产时钟使用 `resolveRaidEvent(state, event)` 的 `{ state, follow? }`，由统一时间线调度后继事件。阶段为 `outbound → guard → fighting`；NPC 返回事件同为 `kind: 'raid'`、`phase: 'returning'`。旧 `resolveRaid` 仅为直接调用兼容，生产不能用它跳过应对窗口。
- 来袭 payload 保留旧 `attackerId/attacker/swordPower/swords/element`，增加实际 `attackers: CombatSword[]`、`returnSeconds`；护身阶段保存 `guards`，主动祭剑保存在 `defending: LaunchSword[]`，交战快照为 `defenders: CombatSword[]`。NPC 返回 payload 为 `{ phase: 'returning', npcId, swordIds, loot? }`，其中 `loot` 是五气合计值。
- `NpcAid = { npcId, swords: CombatSword[], arriveAt, returnSeconds }`。`requestHelp` 和 `requestRaidAid` 都在引擎调用 `canRequestAid`，只接纳持久护法或同门；准备援军立即占用 NPC 的真实空闲飞剑，按距离和速度确定到达时间，战后按实际战损返航。拒绝重复或来不及的请求不写入准备过程的临时状态。来袭途中按当前阶段截止时间判断能否到达，护身阶段可再次发起求援。
- `NpcPatch` 增加 `artifacts?: Artifact[]`、`qiGained?: number`，继续使用 `qiLost/x/y`；`NpcState.artifacts` 是情报、进攻、来袭、援军共用的真实列表。`npcSwordStatus`、`npcCombatDamage`、`npcReturnEvent` 处理所有 NPC 装备状态。存档迁移和校验由集成组维护。
- 来袭检查 `peaceUntil`，护身或战斗途中开启免战也会结束来袭，并释放已祭剑及护身、安排 NPC 返航。普通远程目标通过 `isDivinationVisible` 复用已定位视野。
- `fight.ts` 使用 `FightVm.arts` 渲染 `select#fightswordart[name=swordArt]`；客户端将选择传入上述引擎入口。真实点击曾发现战斗 B 浮窗遮挡祭剑 L 浮窗，集成组已在 fight 路由关闭 B 浮窗；修后回归通过。

## 先失败再修复

1. 先复现普通断剑被删除、NPC 被抢后道行下降，再改共用战损与 NPC 库存模型。
2. 新增主动剑术、实际 NPC 装备、吸收上限与护身阶段测试，修正原先一次结算及合成面板。
3. 补充 NPC 掠夺提前到账、护身祭剑漏算出剑上限、旧 `launchedStats` 缺吸收三项失败用例，再分别修返航入账、计数与兼容回退。
4. 最后补充 NPC 守胜天雷应销毁玩家旧断剑、护身中免战应释放已占用装备两项失败用例；均已由实际入口修复。
5. 旧来袭测试默认到达即出战报，现按真实 `fightEnd` 断言；原先用超高护身的定时调度夹具改成先天罡气挡敌，避免 7 天推进仍未结束护身。离线真气差值来自新增加的 26 秒交战期间恢复，与提前结算不同；断言改为核对真实阶段、战报时刻和离线恢复。
6. 浏览器新号随机产生的普通羊护法可能全军覆没，原测试却要求有幸存剑返航。返航用例改为正式导入时明确准备一把极品 +8 玉虚桃木剑；求援断言同时核对该装备的身份与实际耐久，继续通过真实按钮完成结护法、派援和返航，不放宽存活断言。
7. 真实截图还发现祭剑页把临时目标的攻击、敏捷、生命占位值 0 展示给玩家。集成组将概要改成实际来袭阶段，不显示未推算的敌方面板；新浏览器断言核对“护身抵挡中”且没有“攻击:0”。此项由修复前截图直接证实，新断言是在修复后运行通过，未宣称它先红。

临时红灯日志位于 `/tmp/combat-red.log`、`/tmp/combat-fidelity-red.log`、`/tmp/combat-cap-red.log`、`/tmp/combat-legacy-red.log`、`/tmp/raid-final-red.log`、`/tmp/combat-symmetry-red.log`；它们是本机检查产物，不作为仓库资料。

## 本次验证

- `node --test src/engine/battle.test.ts src/engine/combat.test.ts src/engine/npc.test.ts src/engine/raid.test.ts src/engine/divine.test.ts src/engine/combat-fidelity.test.ts`：133/133 通过，日志 `/tmp/combat-final-tests.log`。
- `npm run typecheck`：通过，日志 `/tmp/combat-typecheck.log`。
- `node tools/parity/combat-regression.mjs`：连续两个随机新号均 42/42 通过，最后一轮日志 `/tmp/combat-browser.log`。独立 Playwright 上下文、固定游戏时钟；通过正式建号、导入准备玩家与护法装备/位置、真实按钮和时间推进完成任务、NPC 出击、真实整点来袭、结护法、5760 秒护身、主动祭剑、延时援军、重复求援拒绝与战损返航；没有注入事件或任务完成状态，没有接触用户存档。
- 实际查看 `tools/parity/shots/fidelity-combat-guard.png`：原定宽布局内的主动剑术选择器与说明正常，祭剑窗口没有被战斗窗口遮挡，概要显示“来袭，护身抵挡中”。截图是临时产物，不提交。
- 本组修改文件 `git diff --check`：通过。

上述是战斗组本次直接执行的结果。全量 `check/build/regression/smoke/parity` 的最终结果由主控汇总，不能用此处局部通过替代整体集成验收。未创建提交、推送或部署。
