# 资料保真修复实施计划

Spec: `docs/reviews/2026-09-27-gameplay-fidelity-audit.md`，用户已授权据现有资料调整及合理推断。

## 全局约束
- 保持 2009-03-24 至仙府开光前版本、纯静态、原页面骨架；无依赖、无提交/推送/部署。
- 已有工作保留。修改前工作树快照在 `/tmp/xiuzhen-fidelity-baseline`。
- 原文锚点优先；不足处明确 reconstructed，并记录来源、选择及局限。
- 游戏时间/种子随机/事件时间线统一；拒绝操作无部分扣费；旧档迁移保留进度资产。
- 测试先复现偏差，再修共享规则与实际入口。最终 check/build/正式浏览器回归/视觉检查。

## 任务与文件边界
1. 经济成长（F01–05、F08、F16、F21、F23）：data/upgrade、artifacts、pills、skills；engine/craft、cultivate、market。维护费导出给 game 调用。共享 game/state/client 由主控集成。
2. 战斗（F07、F09–11、F21 特殊剑）：engine/battle、combat、raid、npc。接口与事件兼容，实际 NPC 装备和战损持久化。
3. 任务与城镇（F06、F13–15、F17–19）：engine/quest、town、treasure，data/quests。新状态定义在各模块；主控维护 GameState/迁移/事件集成。
4. 主控集成（F12、F20、F22）：术数、NPC 护法与独立玩家门派、免战、黑名单；game/state/save、client/pages、迁移与验证。
5. 逐项 review + 整体回归：核对 23 项关闭证据，修复交叉影响，更新 DECISIONS/UNCERTAIN/PROGRESS 和审计处理表。

## 交叉接口预检
| 任务 | 交叉 | 处理 |
|---|---|---|
| 1→4 | 维护费、炼制配方、品质、串行队列 | 1 导出共享函数；4 调用并校验存档 |
| 2→4 | NPC 装备/坐标、剑术、护身阶段 | 2 独占战斗/NPC；4 接页面、情报与校验 |
| 3→4 | 占领/结丹/任务/押镖状态 | 3 模块定义可选字段；4 迁移并接 tick/页面 |
| 2↔3 | 任务战斗目标/战斗回调 | 保留 BattleTarget/QuestLog 核心字段，新增可选字段明确通知 |
| 1/2/3 | 各组测试 | 只改自有相邻测试，最终主控全套运行 |

## 进度
- baseline: 已保存；本次工作区已有修改和未跟踪文件保留。
- Task 1–4: 已完成。经济、战斗、任务、社交与术数接入真实状态；v9迁移和旧档兼容已验证。
- Task 5: 已完成。F01–F23逐项处理表及三份分报告已记录来源、重建公式和局限；DECISIONS-rules §48、UNCERTAIN §10、PROGRESS已更新。
- 最终验证：check 862/862、build、正式入口回归8组、playtest 64/64、smoke 11/11、parity 8/8均通过；不确定清单5/5及diff格式检查通过，已实际查看文曲、门派与祭剑截图。
- 本轮不宣称v9重新自然完成全部138任务；历史v8通关记录保留并明确标注。未提交、推送或部署。
